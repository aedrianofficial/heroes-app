@extends('layouts.landing')
@section('content')
<div class="container">
  <h1>News is working!</h1>
</div>
@endsection