@extends('layouts.user')

@section('content')
  
   
    <h2>User Dashboard</h2>
    <p>You are logged in.</p>
@endsection
